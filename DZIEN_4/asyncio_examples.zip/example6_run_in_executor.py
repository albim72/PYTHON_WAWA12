import asyncio
import time
from concurrent.futures import ThreadPoolExecutor

def blocking_io(x: int) -> int:
    print(f"[blocking_io] start {x}")
    time.sleep(2)
    print(f"[blocking_io] done {x}")
    return x * x

async def main():
    loop = asyncio.get_running_loop()

    with ThreadPoolExecutor(max_workers=3) as pool:
        tasks = []
        for i in range(5):
            fut = loop.run_in_executor(pool, blocking_io, i)
            tasks.append(fut)

        print("[main] Doing other async work while threads run...")
        for _ in range(4):
            await asyncio.sleep(0.5)
            print("[main] tick...")

        results = await asyncio.gather(*tasks)
        print("Results:", results)

if __name__ == "__main__":
    asyncio.run(main())
