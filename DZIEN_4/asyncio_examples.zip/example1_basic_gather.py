import asyncio
import time

async def worker(name: str, delay: float) -> str:
    print(f"[{name}] start (delay={delay})")
    await asyncio.sleep(delay)
    print(f"[{name}] done")
    return f"{name}-result"

async def main():
    print("=== SEKWENCYJNIE ===")
    t0 = time.perf_counter()
    await worker("A", 1)
    await worker("B", 2)
    await worker("C", 3)
    t1 = time.perf_counter()
    print(f"Sequential time: {t1 - t0:.2f}s\n")

    print("=== WSPÓŁBIEŻNIE (gather) ===")
    t2 = time.perf_counter()
    results = await asyncio.gather(
        worker("A", 1),
        worker("B", 2),
        worker("C", 3),
    )
    t3 = time.perf_counter()
    print(f"Concurrent time: {t3 - t2:.2f}s")
    print("Results:", results)

if __name__ == "__main__":
    asyncio.run(main())
