from concurrent.futures import ThreadPoolExecutor
import time

def task(n):
    time.sleep(n)
    return f"Task {n} done"

def done_callback(future):
    print("[CALLBACK]:", future.result())

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=3) as ex:
        for i in [1, 2, 3]:
            f = ex.submit(task, i)
            f.add_done_callback(done_callback)

    print("Główny wątek kończy pracę.")
