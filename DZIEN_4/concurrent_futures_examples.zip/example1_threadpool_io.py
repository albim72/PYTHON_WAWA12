from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

URLS = [
    "https://httpbin.org/get",
    "https://httpbin.org/delay/1",
    "https://httpbin.org/delay/2",
]

def fetch(url):
    r = requests.get(url)
    return url, r.status_code, len(r.text)

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=5) as ex:
        futures = [ex.submit(fetch, url) for url in URLS]

        for f in as_completed(futures):
            url, status, size = f.result()
            print(f"Fetched {url} → {status}, bytes={size}")
