from __future__ import annotations

from events import EventEmmiter
from repository import InventoryRepository


class NotificationService:
    """Serwis odpowiedzialny za powiadomienia o nowych zamówieniach."""

    def __init__(self, event_emitter: EventEmmiter) -> None:
        event_emitter.on("order_placed", self.send_notification)

    def send_notification(self, order_id: int, amount: float) -> None:
        print(
            f"[NOTIFICATION] wysłano powiadomienie o zamówieniu "
            f"#{order_id}, kwota: {amount:.2f} PLN"
        )


class AnalyticsService:
    """Serwis analityczny – zlicza liczbę zamówień i sumaryczny obrót."""

    def __init__(self, event_emitter: EventEmmiter) -> None:
        self.orders_count = 0
        self.total_revenue = 0.0

        event_emitter.on("order_placed", self.register_order)

    def register_order(self, order_id: int, amount: float) -> None:
        self.orders_count += 1
        self.total_revenue += amount
        print(
            f"[ANALYTICS] zarejestrowano zamówienie #{order_id} | "
            f"liczba zamówień: {self.orders_count} | "
            f"łączny obrót: {self.total_revenue:.2f} PLN"
        )


class InventoryService:
    """
    Serwis magazynowy – prawdziwa rezerwacja towaru w bazie SQLite.

    Zasada działania w tym przykładzie (prosta, ale „realna”):
      * w bazie istnieje tabela ``products`` (patrz: InventoryRepository),
      * dla każdego zamówienia rezerwujemy 1 sztukę jednego produktu,
      * identyfikator produktu wyliczamy na podstawie numeru zamówienia,
        żeby przykład był powtarzalny bez rozbudowy domeny.

    Najważniejsze jest to, że:
      * wykonujemy zapytania SQL,
      * zmieniamy stan magazynu (quantity),
      * możemy łatwo sprawdzić przed/po symulacji, co stało się z danymi.
    """

    def __init__(
        self,
        event_emitter: EventEmmiter,
        inventory_repo: InventoryRepository,
        low_stock_threshold: int = 2,
    ) -> None:
        self._repo = inventory_repo
        self._low_stock_threshold = low_stock_threshold

        event_emitter.on("order_placed", self.reserve_stock)

    def reserve_stock(self, order_id: int, amount: float) -> None:
        products = self._repo.list_products()
        if not products:
            print("[INVENTORY] Brak produktów w magazynie – nic nie zarezerwowano.")
            return

        # Prosty, deterministyczny przydział produktu do zamówienia:
        # używamy reszty z dzielenia numeru zamówienia przez liczbę produktów.
        index = order_id % len(products)
        product = products[index]
        product_id = int(product["id"])
        product_name = str(product["name"])
        reserved_qty = 1

        if not self._repo.reserve_product(product_id, reserved_qty):
            print(
                f"[INVENTORY] BRAK STANU! Nie udało się zarezerwować "
                f"{reserved_qty} szt. produktu '{product_name}' "
                f"dla zamówienia #{order_id}"
            )
            return

        updated = self._repo.get_product(product_id)
        remaining = int(updated["quantity"]) if updated is not None else 0

        print(
            f"[INVENTORY] Zarezerwowano {reserved_qty} szt. produktu "
            f"'{product_name}' dla zamówienia #{order_id}. "
            f"Pozostało w magazynie: {remaining} szt."
        )

        if remaining <= self._low_stock_threshold:
            print(
                f"[INVENTORY] UWAGA – niski stan magazynowy produktu "
                f"'{product_name}' (pozostało {remaining} szt.)"
            )
