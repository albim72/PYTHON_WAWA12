from __future__ import annotations

from events import EventEmmiter
from order import Order
from repository import InventoryRepository
from services import NotificationService, AnalyticsService, InventoryService


def main() -> None:
    # 1. Tworzymy event bus
    event_bus = EventEmmiter(debug=True)

    # 2. Tworzymy magazyn oparty na SQLite
    inventory_repo = InventoryRepository()

    print("==== STANY MAGAZYNOWE PRZED SYMULACJĄ ====")
    for row in inventory_repo.list_products():
        print(f"  ID={row['id']}, nazwa='{row['name']}', ilość={row['quantity']} szt.")

    # 3. Rejestracja komponentów
    notifications = NotificationService(event_bus)
    analytics = AnalyticsService(event_bus)
    inventory = InventoryService(event_bus, inventory_repo)

    # 4. Komponent domenowy – składanie zamówień
    order_component = Order(event_bus)

    # 5. Prosta symulacja zamówień
    orders = [
        (101, 1200.00),
        (102, 7500.50),
        (103, 2100.00),
        (104, 1233.90),
        (105, 987.23),
    ]

    for order_id, amount in orders:
        order_component.place_order(order_id, amount)

    print("\n==== STANY MAGAZYNOWE PO SYMULACJI ====")
    for row in inventory_repo.list_products():
        print(f"  ID={row['id']}, nazwa='{row['name']}', ilość={row['quantity']} szt.")

    print("\n==== KONIEC SYMULACJI ====")
    print(f"łączenie zamówień: {analytics.orders_count}")
    print(f"łaczny obrót: {analytics.total_revenue:.2f} PLN")


if __name__ == '__main__':
    main()
