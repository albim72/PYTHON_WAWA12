import asyncio
from typing import AsyncIterator

class AsyncDBConnection:
    def __init__(self, dsn: str):
        self.dsn = dsn
        self.connected = False

    async def __aenter__(self) -> "AsyncDBConnection":
        print(f"[DB] Connecting to {self.dsn} ...")
        await asyncio.sleep(1)
        self.connected = True
        print("[DB] Connected.")
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        print("[DB] Closing connection...")
        await asyncio.sleep(0.5)
        self.connected = False
        print("[DB] Closed.")

    async def fetch_stream(self) -> AsyncIterator[dict]:
        if not self.connected:
            raise RuntimeError("Not connected")
        for i in range(5):
            await asyncio.sleep(0.4)
            yield {"id": i, "value": i * 10}

async def main():
    async with AsyncDBConnection("postgresql://user@localhost/db") as db:
        async for row in db.fetch_stream():
            print("[ROW]", row)

if __name__ == "__main__":
    asyncio.run(main())
