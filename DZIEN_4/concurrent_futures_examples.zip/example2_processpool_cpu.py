from concurrent.futures import ProcessPoolExecutor
import math
import time

def heavy_compute(n):
    total = 0
    for i in range(10_000_00):
        total += math.sqrt(i + n)
    return n, total

if __name__ == "__main__":
    numbers = [10, 11, 12, 13]

    t0 = time.time()
    with ProcessPoolExecutor() as ex:
        results = list(ex.map(heavy_compute, numbers))
    print("Parallel:", results, "time:", time.time() - t0)

    t1 = time.time()
    results_single = [heavy_compute(x) for x in numbers]
    print("Single:", results_single, "time:", time.time() - t1)
