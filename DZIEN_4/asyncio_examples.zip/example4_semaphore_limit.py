import asyncio
import random
import time

async def limited_worker(semaphore: asyncio.Semaphore, idx: int) -> None:
    async with semaphore:
        delay = random.uniform(0.5, 2.0)
        print(f"[worker {idx}] acquired slot, working {delay:.2f}s")
        await asyncio.sleep(delay)
        print(f"[worker {idx}] released slot")

async def main():
    max_concurrent = 3
    sem = asyncio.Semaphore(max_concurrent)

    t0 = time.perf_counter()
    tasks = [asyncio.create_task(limited_worker(sem, i)) for i in range(10)]
    await asyncio.gather(*tasks)
    t1 = time.perf_counter()

    print(f"Total time: {t1 - t0:.2f}s (limit={max_concurrent})")

if __name__ == "__main__":
    asyncio.run(main())
