from concurrent.futures import ThreadPoolExecutor, TimeoutError
import time

def risky(n):
    if n == 2:
        raise ValueError("Problem in task 2!")
    time.sleep(n)
    return f"OK {n}"

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=3) as ex:
        f1 = ex.submit(risky, 1)
        f2 = ex.submit(risky, 2)
        f3 = ex.submit(risky, 5)

        try:
            print("Waiting for f3 with timeout=2...")
            res = f3.result(timeout=2)
            print("Result:", res)
        except TimeoutError:
            print("Timeout! Cancelling f3...")
            f3.cancel()

        try:
            print("Result f2:", f2.result())
        except Exception as e:
            print("Exception from f2:", repr(e))
