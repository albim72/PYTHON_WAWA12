import asyncio

async def long_op():
    print("[long_op] started, 5s sleep")
    try:
        await asyncio.sleep(5)
        print("[long_op] finished normally")
    except asyncio.CancelledError:
        print("[long_op] got CancelledError – cleaning up...")
        raise

async def main():
    task = asyncio.create_task(long_op())

    try:
        await asyncio.wait_for(task, timeout=2.0)
    except asyncio.TimeoutError:
        print("[main] Timeout! Cancelling task...")
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            print("[main] Task was cancelled successfully.")

    print("[main] Done.")

if __name__ == "__main__":
    asyncio.run(main())
