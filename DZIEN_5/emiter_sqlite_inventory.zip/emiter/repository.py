from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Iterable, List, Optional


class InventoryRepository:
    """
    Prosty repozytorium magazynu oparte na SQLite.

    Tabela ``products`` ma pola:
      - id       (INTEGER PRIMARY KEY AUTOINCREMENT)
      - name     (TEXT)  – nazwa towaru
      - quantity (INTEGER) – ilość sztuk na stanie

    Celem tego komponentu jest pokazanie:
      - tworzenia prawdziwej bazy danych,
      - wykonywania zapytań SQL z Pythona,
      - aktualizacji stanu magazynowego po rezerwacji.
    """

    def __init__(self, db_path: str | None = None) -> None:
        # Plik bazy danych w katalogu projektu (domyślnie inventory.db)
        self.db_path = Path(db_path or "inventory.db")
        # check_same_thread=False bo w prostych przykładach czasem używamy
        # połączenia w różnych miejscach, ale nadal w jednym wątku.
        self._conn = sqlite3.connect(self.db_path)
        self._conn.row_factory = sqlite3.Row

        self._init_schema()
        self._seed_if_empty()

    # --- konfiguracja i dane początkowe ---

    def _init_schema(self) -> None:
        """Tworzy tabelę products, jeśli jeszcze nie istnieje."""
        cur = self._conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK(quantity >= 0)
            )
            """
        )
        self._conn.commit()

    def _seed_if_empty(self) -> None:
        """Jeśli magazyn jest pusty – dodaj przykładowe produkty."""
        cur = self._conn.cursor()
        cur.execute("SELECT COUNT(*) FROM products")
        count = cur.fetchone()[0]
        if count:
            return

        sample_products = [
            ("Laptop ANIMA 15", 5),
            ("Monitor 27 QD-OLED", 3),
            ("Klawiatura mechaniczna", 10),
            ("Mysz bezprzewodowa", 12),
            ("Stacja dokująca USB-C", 7),
        ]
        cur.executemany(
            "INSERT INTO products(name, quantity) VALUES(?, ?)",
            sample_products,
        )
        self._conn.commit()

# --- operacje pomocnicze ---

    def list_products(self) -> list[sqlite3.Row]:
        """Zwraca listę wszystkich produktów jako listę wierszy Row."""
        cur = self._conn.cursor()
        cur.execute("SELECT id, name, quantity FROM products ORDER BY id")
        return cur.fetchall()

    def get_product(self, product_id: int) -> Optional[sqlite3.Row]:
        """Pobiera pojedynczy produkt po id."""
        cur = self._conn.cursor()
        cur.execute(
            "SELECT id, name, quantity FROM products WHERE id = ?",
            (product_id,),
        )
        return cur.fetchone()

    def reserve_product(self, product_id: int, quantity: int) -> bool:
        """
        Rezerwuje `quantity` sztuk produktu.

        Zwraca:
            True  – jeśli rezerwacja się udała,
            False – jeśli w magazynie jest za mało sztuk.
        """
        cur = self._conn.cursor()

        # Sprawdzenie aktualnego stanu
        cur.execute(
            "SELECT quantity FROM products WHERE id = ?",
            (product_id,),
        )
        row = cur.fetchone()
        if row is None:
            return False

        current_qty = int(row[0])
        if quantity <= 0:
            return False

        if current_qty < quantity:
            return False

        new_qty = current_qty - quantity
        cur.execute(
            "UPDATE products SET quantity = ? WHERE id = ?",
            (new_qty, product_id),
        )
        self._conn.commit()
        return True

    def close(self) -> None:
        """Zamyka połączenie z bazą (opcjonalne w tym prostym przykładzie)."""
        if self._conn:
            self._conn.close()
