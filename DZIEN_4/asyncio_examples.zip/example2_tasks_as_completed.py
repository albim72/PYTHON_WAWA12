import asyncio
import random

async def job(idx: int) -> str:
    delay = random.uniform(0.5, 2.0)
    print(f"[job {idx}] will take {delay:.2f}s")
    await asyncio.sleep(delay)
    print(f"[job {idx}] finished")
    return f"job-{idx}-result"

async def main():
    tasks = [asyncio.create_task(job(i)) for i in range(5)]

    print("Waiting for jobs (in completion order):")
    for task in asyncio.as_completed(tasks):
        result = await task
        print("  -> got:", result)

    print("All tasks done.")

if __name__ == "__main__":
    asyncio.run(main())
